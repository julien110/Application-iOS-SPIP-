//
//  criteres_auteurs.h
//  spip
//
//  Created by Julien Haïs on 02/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface criteres_auteurs : UIViewController {
    IBOutlet UIScrollView *scrollviewcriteres;
}
- (IBAction)retourmeu:(id)sender;
@end
