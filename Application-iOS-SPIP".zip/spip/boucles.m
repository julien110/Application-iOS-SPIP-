//
//  boucles.m
//  spip
//
//  Created by Julien Haïs on 29/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "boucles.h"
#import "criteres_syndic_articles.h"
#import "criteres_sites.h"
#import "criteres_signatures.h" 
#import "criteres_rubrique.h"
#import "criteres_mots.h"
#import "criteres_hierarchie.h"
#import "cricteres_documents.h"
#import "critere_forums.h"
#import "criteres_articles.h"
#import "criteres_breves.h"
#import "criteres_auteurs.h"
#import "balises_articles.h"
#import "balises_auteurs.h"
#import "balises_breves.h"
#import "balises_documents.h"
#import "balises_forum.h"
#import "balises_hierarchie.h"
#import "balises_mots.h"
#import "balises_rubrique.h"
#import "balises_signatures.h"
#import "balises_sites.h"
#import "balises_syndic_articles.h"

@implementation boucles





- (void)viewDidLoad {
    
    
    
    [scrollviewboucles setScrollEnabled:YES];

    
    [scrollviewboucles setContentSize:CGSizeMake(320, 5210)];
    
    
    
     [super viewDidLoad];
    

    
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)criteres_articles:(id)sender {
    criteres_articles *vue1212 = [[criteres_articles alloc] initWithNibName:nil bundle:nil];
    vue1212.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue1212 animated:YES];
}

- (IBAction)criteres_auteurs:(id)sender {
    criteres_auteurs *vue12125 = [[criteres_auteurs alloc] initWithNibName:nil bundle:nil];
    vue12125.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue12125 animated:YES];
}

- (IBAction)criteres_breves:(id)sender {
    criteres_breves *vue120 = [[criteres_breves alloc] initWithNibName:nil bundle:nil];
    vue120.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue120 animated:YES];
    
}

- (IBAction)criteres_documents:(id)sender {
    cricteres_documents *vue1520 = [[cricteres_documents alloc] initWithNibName:nil bundle:nil];
    vue1520.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue1520 animated:YES];
}

- (IBAction)criteres_forums:(id)sender {
    critere_forums *vue1620 = [[critere_forums alloc] initWithNibName:nil bundle:nil];
    vue1620.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue1620 animated:YES];
}

- (IBAction)criteres_mots:(id)sender {
    criteres_mots *vue1920 = [[criteres_mots alloc] initWithNibName:nil bundle:nil];
    vue1920.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue1920 animated:YES];
}

- (IBAction)criteres_hierarchie:(id)sender {
    criteres_hierarchie *vue3620 = [[criteres_hierarchie alloc] initWithNibName:nil bundle:nil];
    vue3620.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue3620 animated:YES];
}

- (IBAction)criteres_rubrique:(id)sender {
    criteres_rubrique *vue360 = [[criteres_rubrique alloc] initWithNibName:nil bundle:nil];
    vue360.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue360 animated:YES];
}

- (IBAction)criteres_signatures:(id)sender {
    criteres_signatures *vue30 = [[criteres_signatures alloc] initWithNibName:nil bundle:nil];
    vue30.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue30 animated:YES];

}

 - (IBAction)criteres_sites:(id)sender {
     criteres_sites *vue30 = [[criteres_sites alloc] initWithNibName:nil bundle:nil];
     vue30.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
     [self presentModalViewController : vue30 animated:YES];
}

- (IBAction)criteres_syndicarticles:(id)sender {
    criteres_syndic_articles *vue970 = [[criteres_syndic_articles alloc] initWithNibName:nil bundle:nil];
    vue970.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue970 animated:YES];
}

- (IBAction)balises_articles:(id)sender {
    balises_articles *vue9 = [[balises_articles alloc] initWithNibName:nil bundle:nil];
    vue9.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue9 animated:YES];
}

- (IBAction)balises_auteurs:(id)sender {
    balises_auteurs *vue98 = [[balises_auteurs alloc] initWithNibName:nil bundle:nil];
    vue98.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue98 animated:YES];
}

- (IBAction)balises_breves:(id)sender {
    balises_breves *vue93 = [[balises_breves alloc] initWithNibName:nil bundle:nil];
    vue93.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue93 animated:YES];
}

- (IBAction)balises_documents:(id)sender {
    balises_documents *vue90 = [[balises_documents alloc] initWithNibName:nil bundle:nil];
    vue90.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue90 animated:YES];
}

- (IBAction)balises_forums:(id)sender {
    balises_forum *vue023 = [[balises_forum alloc] initWithNibName:nil bundle:nil];
    vue023.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue023 animated:YES];
}

- (IBAction)mots:(id)sender {
    balises_mots *vue125 = [[balises_mots alloc] initWithNibName:nil bundle:nil];
    vue125.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue125 animated:YES];
}

- (IBAction)balises_hierarchie:(id)sender {
    balises_hierarchie *vue1251 = [[balises_hierarchie alloc] initWithNibName:nil bundle:nil];
    vue1251.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue1251 animated:YES];
}

- (IBAction)balises_rubriques:(id)sender {
    balises_rubrique *vue025 = [[balises_rubrique alloc] initWithNibName:nil bundle:nil];
    vue025.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue025 animated:YES];
}

- (IBAction)balises_signatures:(id)sender {
    balises_signatures *vue1295 = [[balises_signatures alloc] initWithNibName:nil bundle:nil];
    vue1295.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue1295 animated:YES];
}

- (IBAction)balises_sites:(id)sender {
    balises_sites *vue05 = [[balises_sites alloc] initWithNibName:nil bundle:nil];
    vue05.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue05 animated:YES];
}

- (IBAction)balises_syndic_articles:(id)sender {
    
    balises_syndic_articles *vue11256 = [[balises_syndic_articles alloc] initWithNibName:nil bundle:nil];
    vue11256.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue11256 animated:YES];
}

- (IBAction)retourmeu:(id)sender {
    
     [self dismissModalViewControllerAnimated:YES];    
}
@end
