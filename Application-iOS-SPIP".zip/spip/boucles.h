//
//  boucles.h
//  spip
//
//  Created by Julien Haïs on 29/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@interface boucles : UIViewController {

    IBOutlet UIScrollView *scrollviewboucles;
    
    IBOutlet UIButton *bienvenue;
    IBOutlet UIButton *bienvenue1;
    
    
    CAKeyframeAnimation *popAnimation;
    
    
}
- (IBAction)criteres_articles:(id)sender;
- (IBAction)criteres_auteurs:(id)sender;
- (IBAction)criteres_breves:(id)sender;
- (IBAction)criteres_documents:(id)sender;
- (IBAction)criteres_forums:(id)sender;
- (IBAction)criteres_mots:(id)sender;
- (IBAction)criteres_hierarchie:(id)sender;
- (IBAction)criteres_rubrique:(id)sender;
- (IBAction)criteres_signatures:(id)sender;
- (IBAction)criteres_sites:(id)sender;
- (IBAction)criteres_syndicarticles:(id)sender;

- (IBAction)balises_articles:(id)sender;
- (IBAction)balises_auteurs:(id)sender;
- (IBAction)balises_breves:(id)sender;
- (IBAction)balises_documents:(id)sender;
- (IBAction)balises_forums:(id)sender;
- (IBAction)mots:(id)sender;
- (IBAction)balises_hierarchie:(id)sender;
- (IBAction)balises_rubriques:(id)sender;
- (IBAction)balises_signatures:(id)sender;
- (IBAction)balises_sites:(id)sender;
- (IBAction)balises_syndic_articles:(id)sender;

- (IBAction)retourmeu:(id)sender;

@end
