//
//  balises_sites.h
//  spip
//
//  Created by Julien Haïs on 04/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface balises_sites : UIViewController {
    IBOutlet UIScrollView *scrollviewboucles;

}
- (IBAction)retourmeu:(id)sender;
@end
