//
//  installation.h
//  spip
//
//  Created by Julien Haïs on 19/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@interface installation : UIViewController {
    
    IBOutlet UILabel *bienvenue;

    
    CAKeyframeAnimation *popAnimation;
    
    
    IBOutlet UIScrollView *scrollviewinstallation;
}
- (IBAction)retourmenu:(id)sender;
    
@end
