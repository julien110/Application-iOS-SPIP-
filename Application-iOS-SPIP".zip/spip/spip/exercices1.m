//
//  exercices1.m
//  spip
//
//  Created by Julien Haïs on 20/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "exercices1.h"
#import "menu.h"
#import "exercices1help.h"
#import "exercices2.h"


@implementation exercices1




- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([text isEqual:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
        [editeur setReturnKeyType: UIReturnKeyDone];
    }
    return YES;
}
 



- (IBAction)valider:(id)sender {
    
    if ([editeur.text isEqualToString:@"<BOUCLEarticles (ARTICLES) {tout} >\n#TITRE\n</BOUCLEarticles>"]) {
        
        resultat.text = @"Vrai";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Réussi !" message:@"Vous avez réussi le 1er execice." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];
        exercices2 *vue345 = [[exercices2 alloc] initWithNibName:nil bundle:nil];
        vue345.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController : vue345 animated:YES];
    
        
        
    }
    
    else {
        
        resultat.text = @"Faux";
    
    }
}




- (IBAction)menu:(id)sender {
    menu *vue345 = [[menu alloc] initWithNibName:nil bundle:nil];
    vue345.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue345 animated:YES];
}

- (IBAction)cache:(id)sender {
    
    [editeur resignFirstResponder];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [editeur release];
    [resultat release];
   
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
     
}

- (void)viewDidUnload
{
    [editeur release];
    editeur = nil;
    [resultat release];
    resultat = nil;
 
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)aide:(id)sender {
    exercices1help *vue2 = [[exercices1help alloc] initWithNibName:nil bundle:nil];
    vue2.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    [self presentModalViewController : vue2 animated:YES];
}


@end
