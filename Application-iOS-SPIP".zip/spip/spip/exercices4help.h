//
//  exercices4help.h
//  spip
//
//  Created by Julien Haïs on 22/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface exercices4help : UIViewController {
    
}
-(IBAction) retour;
@end
