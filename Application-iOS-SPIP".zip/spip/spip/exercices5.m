//
//  exercices5.m
//  spip
//
//  Created by Julien Haïs on 22/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "exercices5.h"
#import "menu.h"
#import "exercices5help.h"
#import "fini.h"


@implementation exercices5


- (IBAction)aide:(id)sender {
    exercices5help *vue2ppap = [[exercices5help alloc] initWithNibName:nil bundle:nil];
    vue2ppap.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    [self presentModalViewController : vue2ppap animated:YES];
}






- (IBAction)valider:(id)sender {
    
    if ([editeur.text isEqualToString:@"<BOUCLEdernier (RUBRIQUES) {id_mot=voiture} >\n#TITRE\n</BOUCLEdernier>"]) {
        
        resultat.text = @"Vrai";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Fin !" message:@"Vous avez réussi tout les exercices." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];
        fini *vue345 = [[fini alloc] initWithNibName:nil bundle:nil];
        vue345.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController : vue345 animated:YES];
        
        
    }
    
    else {
        
        resultat.text = @"Faux";
        
    }
}


- (IBAction)menu:(id)sender {
    menu *vue345 = [[menu alloc] initWithNibName:nil bundle:nil];
    vue345.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    [self presentModalViewController : vue345 animated:YES];
}

- (IBAction)cache:(id)sender {
    
    [editeur resignFirstResponder];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
