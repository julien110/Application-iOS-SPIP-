//
//  spipAppDelegate.m
//  spip
//
//  Created by Julien Haïs on 17/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "spipAppDelegate.h"
#import "spipViewController.h"

@implementation spipAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([text isEqual:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}


@end
