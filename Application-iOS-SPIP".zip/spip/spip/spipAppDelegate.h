//
//  spipAppDelegate.h
//  spip
//
//  Created by Julien Haïs on 17/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class spipViewController;

@interface spipAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    spipViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet spipViewController *viewController;

@end
