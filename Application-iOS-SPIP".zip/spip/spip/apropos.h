//
//  apropos.h
//  spip
//
//  Created by Julien Haïs on 23/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface apropos : UIViewController {
    
}
- (IBAction)retour:(id)sender;
@end
