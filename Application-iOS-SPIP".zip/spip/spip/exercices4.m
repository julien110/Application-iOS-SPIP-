//
//  exercices4.m
//  spip
//
//  Created by Julien Haïs on 22/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "exercices4.h"
#import "menu.h"
#import "exercices4help.h"
#import "exercices5.h"


@implementation exercices4


- (IBAction)aide:(id)sender {
    exercices4help *vue2pap = [[exercices4help alloc] initWithNibName:nil bundle:nil];
    vue2pap.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    [self presentModalViewController : vue2pap animated:YES];
}






- (IBAction)valider:(id)sender {
    
    if ([editeur.text isEqualToString:@"<BOUCLEtest (ARTICLES) {tout} >\n#TITRE\n#TEXTE\n</BOUCLEtest>"]) {
        // Afficher le titre, l'auteur, et le contenu de tout les articles.
        // La boucle a pour nom "test".
        resultat.text = @"Vrai";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Réussi !" message:@"Vous avez réussi le 4eme execice." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];
        exercices5 *vue345 = [[exercices5 alloc] initWithNibName:nil bundle:nil];
        vue345.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController : vue345 animated:YES];
        
        
    }
    
    else {
        
        resultat.text = @"Faux";
        
    }
}


- (IBAction)menu:(id)sender {
    menu *vue345 = [[menu alloc] initWithNibName:nil bundle:nil];
    vue345.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    [self presentModalViewController : vue345 animated:YES];
}

- (IBAction)cache:(id)sender {
    
    [editeur resignFirstResponder];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
