//
//  exercices.h
//  spip
//
//  Created by Julien Haïs on 20/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface exercices : UIViewController {
    IBOutlet UIButton *commence;
}
- (IBAction)commencer:(id)sender;
- (IBAction)retour:(id)sender;

@end
