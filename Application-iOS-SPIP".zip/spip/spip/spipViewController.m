//
//  spipViewController.m
//  spip
//
//  Created by Julien Haïs on 17/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "spipViewController.h"
#import "installation.h"
#import "menu.h"


@implementation spipViewController



- (IBAction)icon1:(id)sender {
    
    
    
}



- (void)dealloc
{
    [imgstart release];
    [img release];

    [ifile1 release];
    [label release];
    [label1 release];
    [img2 release];
    [label3 release];
    [img3 release];
    [label4 release];
    [img4 release];
    [label5 release];
    [img5 release];
    [label6 release];
    [img6 release];
    [label7 release];
    [img7 release];
    [label8 release];
    [img8 release];
    [label9 release];
    [img9 release];
    [label10 release];
    [img10 release];
    [label11 release];
    [img11 release];
    [label12 release];
    [img12 release];
    [label13 release];
    [img13 release];
    [S release];
    [P release];
    [PP release];
    [I release];
    [touchme release];
    [touchmefinish release];
    [Sfinish release];
    [Pfinish release];
    [Ifinish release];
    [PPfinish release];
    [touchmefinish release];
    [super dealloc];
    
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
-(void)viewWillAppear:(BOOL)animated {
    
    [popAnimation setDuration:1.0];
    
    
    [bienvenue setHidden:YES];
    
    [self performSelector:@selector(popView:)withObject:bienvenue afterDelay:5.5];
    
    
    
    
    
    
    
    
}


-(void)popView:(UIView*)view {
    
    [view setHidden:NO];
    [[view layer] addAnimation:popAnimation forKey:@"tranform.scale"];
    
    
    
}
- (void)viewDidLoad {
    
    
    
    CGRect basketTopFrame = basketTop.frame;
    basketTopFrame.origin.y = -basketTopFrame.size.height;
    
    CGRect basketBottomFrame = basketBottom.frame;
    basketBottomFrame.origin.y = self.view.bounds.size.height;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:1.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    basketTop.frame = basketTopFrame;
    basketBottom.frame = basketBottomFrame;
    
    [UIView commitAnimations];
    
    
    
    [super viewDidLoad];
    
    popAnimation = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
    popAnimation.keyTimes = [NSArray arrayWithObjects: [NSNumber numberWithFloat:0.0],
                             [NSNumber numberWithFloat:0.7],
                             [NSNumber numberWithFloat:1.0], nil];
    popAnimation.values = [NSArray arrayWithObjects: [NSNumber numberWithFloat:0.01],
                           [NSNumber numberWithFloat:1.1],
                           [NSNumber numberWithFloat:1.0], nil];
    
    [popAnimation retain];
    [UIView commitAnimations];
    
    
    
    
    touchme.hidden = YES;
    
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.2];
    label.center = ifile1.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:3.0];
    [UIView setAnimationDelay:9.0];
    touchme.center = touchmefinish.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.3];
    label1.center = img2.center;
    [UIView commitAnimations];

    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.75];
    label3.center = img3.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.4];
    label4.center = img4.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.85];
    label5.center = img5.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.6];
    label6.center = img6.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.3];
    label7.center = img7.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.0];
    label8.center = img8.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.4];
    label9.center = img9.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.55];
    label10.center = img10.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.2];
    label11.center = img11.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.75];
    label12.center = img12.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:6.6];
    label13.center = img13.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:7.6];
    touchme.center = touchmefinish.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:3.0];
    [UIView setAnimationDelay:8.6];
    S.center = Sfinish.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:3.0];
    [UIView setAnimationDelay:8.6];
    P.center = Pfinish.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:3.0];
    [UIView setAnimationDelay:8.6];
    I.center = Ifinish.center;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:3.0];
    [UIView setAnimationDelay:8.6];
    PP.center = PPfinish.center;
    [UIView commitAnimations];
    

    
    
    
    
    [UIView animateWithDuration:2.0 animations:^(void) {
        [UIView setAnimationDelay:9.6];
        touchme.hidden = NO;
        touchme.transform = CGAffineTransformMakeScale(2.0, 2.0);
    } completion:^(BOOL finished) {
        if(finished){
            [UIView animateWithDuration:1.0 animations:^(void) {
                [UIView setAnimationDelay:0];
                touchme.transform = CGAffineTransformMakeScale(1.0, 1.0);
                [UIView setAnimationDelay:1.6];
                touchme.hidden = YES;
                [UIView commitAnimations];
            }];
        }
    }]; 
    

    
    
    
    
    


    

    
   
    
    
    if (![@"1" isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"alert"]]) {
        [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:@"alert"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Bienvenue sur SPIP" message:@"Merci d'avoir téléchargé l'application SPIP\nBonne navigation!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];
    }
    
}



- (void)viewDidUnload {
    
    [imgstart release];
    imgstart = nil;
    [img release];
    img = nil;

    [ifile1 release];
    ifile1 = nil;
    [label release];
    label = nil;
    [label1 release];
    label1 = nil;
    [img2 release];
    img2 = nil;
    [label3 release];
    label3 = nil;
    [img3 release];
    img3 = nil;
    [label4 release];
    label4 = nil;
    [img4 release];
    img4 = nil;
    [label5 release];
    label5 = nil;
    [img5 release];
    img5 = nil;
    [label6 release];
    label6 = nil;
    [img6 release];
    img6 = nil;
    [label7 release];
    label7 = nil;
    [img7 release];
    img7 = nil;
    [label8 release];
    label8 = nil;
    [img8 release];
    img8 = nil;
    [label9 release];
    label9 = nil;
    [img9 release];
    img9 = nil;
    [label10 release];
    label10 = nil;
    [img10 release];
    img10 = nil;
    [label11 release];
    label11 = nil;
    [img11 release];
    img11 = nil;
    [label12 release];
    label12 = nil;
    [img12 release];
    img12 = nil;
    [label13 release];
    label13 = nil;
    [img13 release];
    img13 = nil;
    [S release];
    S = nil;
    [P release];
    P = nil;
    [PP release];
    PP = nil;
    [I release];
    I = nil;
    [touchme release];
    touchme = nil;
    [touchmefinish release];
    touchmefinish = nil;
    [Sfinish release];
    Sfinish = nil;
    [Pfinish release];
    Pfinish = nil;
    [Ifinish release];
    Ifinish = nil;
    [PPfinish release];
    PPfinish = nil;
    [touchmefinish release];
    touchmefinish = nil;
    [super viewDidUnload];
    
    
    
    
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



- (IBAction)icon2:(id)sender {
}

- (IBAction)icon3:(id)sender {
}

- (IBAction)icon4:(id)sender {
}

- (IBAction)icon5:(id)sender {
}

- (IBAction)icon6:(id)sender {
}
- (IBAction)bienvenu1:(id)sender {
    menu *vue1 = [[menu alloc] initWithNibName:nil bundle:nil];
    vue1.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue1 animated:YES];
    
}
@end


