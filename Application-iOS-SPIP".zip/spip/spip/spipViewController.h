//
//  spipViewController.h
//  spip
//
//  Created by Julien Haïs on 17/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface spipViewController : UIViewController {

    IBOutlet UIImageView *basketTop;
    IBOutlet UIImageView *basketBottom;
    IBOutlet UIButton *bienvenue;
    IBOutlet UIImageView *imgstart;
    IBOutlet UIImageView *img;
    
    
    IBOutlet UILabel *label13;
    IBOutlet UIImageView *img13;
    IBOutlet UILabel *label12;
    IBOutlet UIImageView *img12;
    IBOutlet UILabel *label11;
    IBOutlet UIImageView *img11;
    IBOutlet UILabel *label10;
    IBOutlet UIImageView *img10;
    IBOutlet UILabel *label9;
    IBOutlet UIImageView *img9;
    IBOutlet UILabel *label8;
    IBOutlet UIImageView *img8;
    IBOutlet UILabel *label7;
    IBOutlet UIImageView *img7;
    IBOutlet UILabel *label6;
    IBOutlet UIImageView *img6;
    IBOutlet UILabel *label5;
    IBOutlet UIImageView *img5;
    IBOutlet UILabel *label4;
    IBOutlet UIImageView *img4;
    IBOutlet UILabel *label3;
    IBOutlet UIImageView *img3;
    IBOutlet UILabel *label1;
    IBOutlet UIImageView *img2;
    IBOutlet UILabel *label;
   
    IBOutlet UIImageView *S;
    IBOutlet UIImageView *P;
    IBOutlet UIImageView *PP;
    IBOutlet UIImageView *I;
    IBOutlet UILabel *touchme;
    IBOutlet UIImageView *touchmefinish;
    IBOutlet UIImageView *Sfinish;
    IBOutlet UIImageView *Pfinish;
    IBOutlet UIImageView *Ifinish;
    IBOutlet UIImageView *PPfinish;
   
    IBOutlet UIImageView *ifile1;
    CAKeyframeAnimation *popAnimation;
}


- (IBAction)bienvenu1:(id)sender;


- (IBAction)icon1:(id)sender;
- (IBAction)icon2:(id)sender;
- (IBAction)icon3:(id)sender;
- (IBAction)icon4:(id)sender;
- (IBAction)icon5:(id)sender;
- (IBAction)icon6:(id)sender;



@end
