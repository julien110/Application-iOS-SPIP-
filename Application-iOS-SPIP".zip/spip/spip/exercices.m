//
//  exercices.m
//  spip
//
//  Created by Julien Haïs on 20/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "exercices.h"
#import "exercices1.h"


@implementation exercices

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    commence.clipsToBounds = YES;
    [commence.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [commence.layer setBorderWidth:0];
    [commence.layer setCornerRadius:10.0f];
    [commence.layer setMasksToBounds:YES];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)commencer:(id)sender {
    exercices1 *vue345 = [[exercices1 alloc] initWithNibName:nil bundle:nil];
    vue345.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue345 animated:YES];
}

- (IBAction)retour:(id)sender {
    [self dismissModalViewControllerAnimated:YES];   
}
@end
