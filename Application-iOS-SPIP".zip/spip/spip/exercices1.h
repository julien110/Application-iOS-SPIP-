//
//  exercices1.h
//  spip
//
//  Created by Julien Haïs on 20/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface exercices1 : UIViewController {
    
    IBOutlet UITextView *editeur;
    IBOutlet UILabel *resultat;
    UIButton *keyboardcache;
}
- (IBAction)aide:(id)sender;
- (IBAction)valider:(id)sender;
- (IBAction)menu:(id)sender;
- (IBAction)cache:(id)sender;



@end
