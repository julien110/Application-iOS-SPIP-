//
//  installation.m
//  spip
//
//  Created by Julien Haïs on 19/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "installation.h"
#import "spipViewController.h"
#import "menu.h"


@implementation installation



- (void)viewDidLoad {
    
    
    
    [scrollviewinstallation setScrollEnabled:YES];
    
    [scrollviewinstallation setContentSize:CGSizeMake(320, 1400)];
    
    

    
    
    
    
    [super viewDidLoad];
    

    
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
   
    
    [scrollviewinstallation release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle



- (void)viewDidUnload
{
  
    [scrollviewinstallation release];
    scrollviewinstallation = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (IBAction)retourmenu:(id)sender {
     [self dismissModalViewControllerAnimated:YES];    
}
@end
