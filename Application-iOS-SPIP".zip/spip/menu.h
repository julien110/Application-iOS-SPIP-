//
//  menu.h
//  spip
//
//  Created by Julien Haïs on 22/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <MessageUI/MessageUI.h>


@interface menu : UIViewController <UIActionSheetDelegate, MFMailComposeViewControllerDelegate> {
 
    IBOutlet UIButton *bienvenue;
    IBOutlet UIButton *bienvenue1;
    IBOutlet UIButton *bienvenue2;
    IBOutlet UIButton *bienvenue3;
    IBOutlet UIButton *bienvenue4;
    
    CAKeyframeAnimation *popAnimation;
    
    
}
    
- (IBAction)boutoninstallation;
- (IBAction)boutonboucles:(id)sender;
- (IBAction)boutonexercices:(id)sender;
- (IBAction)boutonexemples:(id)sender;
- (IBAction)boutonsources:(id)sender;
- (IBAction)email:(id)sender;

@end
