//
//  menu.m
//  spip
//
//  Created by Julien Haïs on 22/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "menu.h"
#import "spipAppDelegate.h"
#import "installation.h"
#import "boucles.h"
#import "exemples.h"
#import "exercices.h"
#import "apropos.h"
#import "sources.h"


@implementation menu







-(void)viewWillAppear:(BOOL)animated {
    
    [popAnimation setDuration:1.0];
    
    
    [bienvenue setHidden:YES];
    
    [self performSelector:@selector(popView:)withObject:bienvenue afterDelay:0.35];
    [self performSelector:@selector(popView:)withObject:bienvenue1 afterDelay:0.5];
    [self performSelector:@selector(popView:)withObject:bienvenue2 afterDelay:0.65];
    [self performSelector:@selector(popView:)withObject:bienvenue3 afterDelay:0.75];
    [self performSelector:@selector(popView:)withObject:bienvenue4 afterDelay:0.90];
    

    
}


-(void)popView:(UIView*)view {
    
    [view setHidden:NO];
    [[view layer] addAnimation:popAnimation forKey:@"tranform.scale"];
    
    
    
}


- (void)viewDidLoad {
    

    bienvenue.clipsToBounds = YES;
    [bienvenue.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [bienvenue.layer setBorderWidth:0];
    [bienvenue.layer setCornerRadius:10.0f];
    [bienvenue.layer setMasksToBounds:YES];
    
    bienvenue1.clipsToBounds = YES;
    [bienvenue1.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [bienvenue1.layer setBorderWidth:0];
    [bienvenue1.layer setCornerRadius:10.0f];
    [bienvenue1.layer setMasksToBounds:YES];
    
    bienvenue2.clipsToBounds = YES;
    [bienvenue2.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [bienvenue2.layer setBorderWidth:0];
    [bienvenue2.layer setCornerRadius:10.0f];
    [bienvenue2.layer setMasksToBounds:YES];
    
    bienvenue3.clipsToBounds = YES;
    [bienvenue3.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [bienvenue3.layer setBorderWidth:0];
    [bienvenue3.layer setCornerRadius:10.0f];
    [bienvenue3.layer setMasksToBounds:YES];

    bienvenue4.clipsToBounds = YES;
    [bienvenue4.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [bienvenue4.layer setBorderWidth:0];
    [bienvenue4.layer setCornerRadius:10.0f];
    [bienvenue4.layer setMasksToBounds:YES];
    
    [super viewDidLoad];
    
    popAnimation = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
    popAnimation.keyTimes = [NSArray arrayWithObjects: [NSNumber numberWithFloat:0.0],
                             [NSNumber numberWithFloat:0.7],
                             [NSNumber numberWithFloat:1.0], nil];
    popAnimation.values = [NSArray arrayWithObjects: [NSNumber numberWithFloat:0.01],
                           [NSNumber numberWithFloat:1.1],
                           [NSNumber numberWithFloat:1.0], nil];
    
    [popAnimation retain];
    [UIView commitAnimations];
    
}


-(IBAction)boutoninstallation {
    
    installation *vue2 = [[installation alloc] initWithNibName:nil bundle:nil];
    vue2.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue2 animated:YES];
    
}

- (IBAction)boutonboucles:(id)sender {
    
    boucles *vue3 = [[boucles alloc] initWithNibName:nil bundle:nil];
    vue3.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue3 animated:YES];
    
}

- (IBAction)boutonexemples:(id)sender {
    
    exemples *vue38 = [[exemples alloc] initWithNibName:nil bundle:nil];
    vue38.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue38 animated:YES];
    
}

- (IBAction)boutonsources:(id)sender {
    
    sources *vue345 = [[sources alloc] initWithNibName:nil bundle:nil];
    vue345.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue345 animated:YES];
    
}

- (IBAction)boutonexercices:(id)sender {
    
    exercices *vue345 = [[exercices alloc] initWithNibName:nil bundle:nil];
    vue345.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController : vue345 animated:YES];
}

- (IBAction)email:(id)sender {
    
   	UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"Choisissez votre option" delegate:self cancelButtonTitle:@"Annuler" destructiveButtonTitle:@"Laisser un commentaire" otherButtonTitles:@"À propos", @"Me contacter", nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
	[popupQuery showInView:self.view];
	[popupQuery release];
    
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	if (buttonIndex == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Service indisponnible" message:@"Ce service n'est pas encore disponnible directement\nMerci de voter sur l'app store !" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];

	} 
    else if (buttonIndex == 1) {
		
        apropos *otherAppsView = [[apropos alloc] initWithNibName:nil bundle:nil];
        otherAppsView.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
        [self presentModalViewController:otherAppsView animated:YES];
	} 
    
	
    else if (buttonIndex == 2) {
        
        MFMailComposeViewController *mailComposer = [[MFMailComposeViewController alloc] init];
        mailComposer.mailComposeDelegate = self;
        
        if ([MFMailComposeViewController canSendMail]) {
            [mailComposer setToRecipients:[NSArray arrayWithObjects:@"julien-110@hotmail.fr", nil]];
            [mailComposer setSubject:@"Spip Apps"];
            [mailComposer setMessageBody:nil isHTML:NO];
            [self presentModalViewController:mailComposer animated:YES];
        }
	}
}

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    [self dismissModalViewControllerAnimated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
