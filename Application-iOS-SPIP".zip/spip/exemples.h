//
//  exemples.h
//  spip
//
//  Created by Julien Haïs on 05/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@interface exemples : UIViewController {
    
    IBOutlet UIScrollView *scrollviewexemples;
}
- (IBAction)retourmeu:(id)sender;
@end
