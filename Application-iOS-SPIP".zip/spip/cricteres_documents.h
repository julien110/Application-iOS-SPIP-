//
//  cricteres_documents.h
//  spip
//
//  Created by Julien Haïs on 02/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface cricteres_documents : UIViewController {
    IBOutlet UIScrollView *scrollviewcriteres;
}
- (IBAction)retourmeu:(id)sender;
@end
