//
//  criteres_sites.h
//  spip
//
//  Created by Julien Haïs on 03/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface criteres_sites : UIViewController {
    IBOutlet UIScrollView *scrollviewcriteres;
}
- (IBAction)retourmeu:(id)sender;
@end
