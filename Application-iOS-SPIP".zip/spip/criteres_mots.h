//
//  criteres_mots.h
//  spip
//
//  Created by Julien Haïs on 03/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface criteres_mots : UIViewController {
    IBOutlet UIScrollView *scrollviewcriteres;
}
- (IBAction)retourmeu:(id)sender;
@end
